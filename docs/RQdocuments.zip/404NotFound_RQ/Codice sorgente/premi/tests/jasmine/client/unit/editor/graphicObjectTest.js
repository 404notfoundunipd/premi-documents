describe('graphicObject', function () {
    var obj = null;
    beforeEach(module('premi'));

    beforeEach(inject(function(GObject){
        obj = new GObject;

    }));

    it('default init correctly set variables', function(){
        obj.initByDefault();
        expect(obj.info.dataX).toBe(0);
        expect(obj.info.dataY).toBe(0);
        expect(obj.info.dataZ).toBe(0);
        expect(obj.info.width).toBe(100);
        expect(obj.info.height).toBe(100);
        expect(obj.info.scale).toBe(1);
        expect(obj.info.lvl).toBe(0);
    });

    it('resize works', function(){
        obj.initByDefault();
        obj.resize(150,150);
        expect(obj.info.height).toBe(150);
        expect(obj.info.width).toBe(150);
    });

    it('resize works', function(){
        obj.initByDefault();
        obj.resize(150,150);
        expect(obj.info.height).toBe(150);
        expect(obj.info.width).toBe(150);
    });

    it('drag works', function(){
        obj.initByDefault();
        obj.drag(100,200);
        expect(obj.info.dataX).toBe(100);
        expect(obj.info.dataY).toBe(200);
    });

    it('init by JSON return the reference to the object', function(){
        var tmp = {
            test: 'test'
        };
        obj.initByJSON(tmp);
        expect(obj.getJSON()).toBe(tmp);
    });

});