angular.module("premi.editor")
	.controller("editorCtrl", [
		function(){
			$('main').css('padding-left','64px');
		}]);