angular.module("premi.editor")
	.config(['$urlRouterProvider', '$stateProvider', '$locationProvider',
		function($urlRouterProvider, $stateProvider, $locationProvider){

			$locationProvider.html5Mode(true);

			$stateProvider
				.state('premi.editor', {
					abstract: true,
					views: {
						'' : {
							templateUrl: 'client/editor/views/editor.ng.html',
							controller: 'editorCtrl',
						},
					},
					params: {
						'idpres': ':idpres',
					},
					resolve: {
						currentUser : ["$meteor", function($meteor){
					    	return $meteor.requireUser();
					    }]
					}
				});

			$urlRouterProvider
			//	.when('/', '/home')
				.when('/editor/:idpres', '/editor/:idpres/frame');
			//	.otherwise('home');
		}
	]);