/**
    * Name:         modTrailCtrl
    * Package:      premi/client/trailsEditor/controllers
    * Author:       Camborata Marco
    * Date:         2015-08-06

    * Use:
    Controller della view modTrail.ng. Permette, tramite lo $scope, di modificare
    un trail in ogni suo aspetto, aggiungendo o togliendo frame, o creando percorsi
    di specializzazione. Fornisce all’utente la possibilità di scorrere il percorso con i
    quattro tasti freccia della tastiera

    
    * Changes:
    Version     Date        Who                 Changes             Reason
    ----------------------------------------------------------------------------
    0.5         2015-08-14  Camborata Marco     Riscritto l'algoritmo 
                                                di caricamento dei frame
    ----------------------------------------------------------------------------
    0.4         2015-08-08  Camborata Marco     Aggiunto  visualizzazione e
                                                inserimento dei frame
    ----------------------------------------------------------------------------
    0.3         2015-08-07  Camborata Marco     aggiunti tasti di scorrimento
    ----------------------------------------------------------------------------
    0.2         2015-08-06  Camborata Marco     Aggiunti metodi
    ----------------------------------------------------------------------------
    0.1         2015-08-06  Camborata Marco     Inizio scrittura del codice
    ----------------------------------------------------------------------------

    * Created by 404Notfound for Premi - Better than Prezi!

    * Premi is a free software: you can redistribute it and/or modify
    * it under the terms of the GNU General Public License as published by
    * the Free Software Foundation, either version 3 of the License, or
    * (at your option) any later version.

    * This program is distributed in the hope that it will be useful,
    * but WITHOUT ANY WARRANTY; without even the implied warranty of
    * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    * GNU General Public License for more details.

    * You should have received a copy of the GNU General Public License
    * along with this program. If not, see <http://www.gnu.org/licenses/>
*/

angular.module("premi.editor.trailsEditor")
	.controller("modTrailCtrl", ['$meteor','$scope', '$stateParams', 'TrailFactory',
		function($meteor,$scope, $stateParams,TrailFactory){

            $(document).ready(function(){
                $('.tooltipped').tooltip({delay: 50});
            });
            
			var selectedFrameOut=0;

            var MTrail = TrailFactory;
            var frames = {};
            var infoG = Infographics.findOne({'presid':$stateParams.idpres})
            var frameCollection = Frames.find({"presid": $stateParams.idpres,'_id':{$in:infoG.framesId}}).fetch();
            var trailCollection = Trails.findOne({"_id" : $stateParams.idtrail}); 
            var idFrames = [];
            var trilly = [[]];

            $scope.showInSide = false;
            $scope.selectedFrameOut = "";

            $scope.test = function(){
				$scope.save();
			};

			$scope.save = function () {
				$meteor.call('updateTrail',$stateParams.idtrail,{trail : MTrail.getTrail()});
			}

            $scope.showSideBarDx = function(){
            	$scope.showInSide = !$scope.showInSide;
            };
			$scope.addFrameAfterCurrent = function(){
                if($scope.selectedFrameOut)
				    MTrail.insertSlideAfterCurrent(frames[$scope.selectedFrameOut]._id);
                $scope.selectedFrameOut = null;
			};
			$scope.addFrameBeforeCurrent = function(){
                if($scope.selectedFrameOut)
				    MTrail.insertSlideBeforeCurrent(frames[$scope.selectedFrameOut]._id);
                $scope.selectedFrameOut = null;
			};
			$scope.addFrameToSpecCurrent = function(){
				if($scope.selectedFrameOut)
                    MTrail.insertSlideInSpecTrail(frames[$scope.selectedFrameOut]._id);
                $scope.selectedFrameOut = null;
			};
			$scope.removeCurrentFrame = function(){
				MTrail.removeCurrentSlide();
			};

			$scope.selectFrameOut = function(idFrame){
				$scope.selectedFrameOut = idFrame;
			};

			$scope.nextSlide = function(){
				MTrail.nextSlide();
			};

			$scope.previousSlide = function(){
				MTrail.prevSlide();
			};

			$scope.enterInCheckPoint = function(){
				if(MTrail.isCurrentSlideChkPnt()){
                    MTrail.enterInCheckPoint();
                }
			};

			$scope.returnToCheckPoint = function(){
				MTrail.returnToCheckPoint();
			};

			$scope.goToFrame = function(IdSlide){
				MTrail.goToSlide(IdSlide);
			};

            $scope.isTrailEmpty = function(){
                return MTrail.isTrailEmpty();
            };

            $scope.getCurrentId = function(){
                return MTrail.getCurrentId();
            };

            $scope.getCurrentContent = function(){
                return frames[MTrail.getCurrentId()].content;
            };

            $scope.getFrames = function(){
                return frames;
            };

            $scope.isFrameInTrail = function(idFrame){
                return MTrail.isSlideInTrail(idFrame);
            };

			$scope.$on('nextSlide', function () {
                $scope.nextSlide();
                $scope.$apply();
            });

            $scope.$on('previousSlide', function () {
               $scope.previousSlide(); 
               $scope.$apply();
            });

            $scope.$on('enterInCheckPoint', function(){
                $scope.enterInCheckPoint();
                $scope.$apply();
            });

            $scope.$on('returnToCheckPoint', function(){
                $scope.returnToCheckPoint();
                $scope.$apply();
            });

            /*$scope.$on('selectFrame',function (event,args) { 	
             	selectedFrame = args;
             	//alert("Frame : "+frames[args]._id+" Pos : "+args);
            });*/

            $scope.$on('goToFrame',function (event,args){
            	$scope.goToFrame(args);
                $scope.$apply();
            	//$scope.showSideBarDx();
            });

            trilly = trailCollection.trail;
            console.log(trailCollection.trail);
            for(var i=0;i<frameCollection.length;i++){
                idFrames[i] = frameCollection[i]._id;
                frames[frameCollection[i]._id] = frameCollection[i];
            }
            MTrail.initPath(idFrames,trilly);
            document.addEventListener('keydown', function (e) {
                    var keyCode = e.keyCode || e.which,
                        arrow = {
                            left: 37,
                            up: 38,
                            right: 39,
                            down: 40
                        };
                    switch (keyCode) {
                        case arrow.left:
                            $scope.$emit('previousSlide');
                            break;
                        case arrow.up:
                            $scope.$emit('returnToCheckPoint');
                            break;
                        case arrow.right:
                            $scope.$emit('nextSlide');
                            break;
                        case arrow.down:
                            $scope.$emit('enterInCheckPoint');
                            break;
                    }
            });
		}]);