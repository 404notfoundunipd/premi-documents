angular.module("premi.editor.trailsEditor")
	.config(['$urlRouterProvider', '$stateProvider', '$locationProvider',
		function($urlRouterProvider, $stateProvider, $locationProvider){

			$locationProvider.html5Mode(true);

			$stateProvider
				.state('premi.editor.trails', {
					abstract: true,
					views: {
						'' : {
							template: '<div ui-view></div>',
							controller: 'trailsEditorCtrl',
						},
					},
					data: {
						defaultState: 'premi.editor.trails.list'
					}
				})
				.state('premi.editor.trails.list', {
					url: '/editor/:idpres/trails',
					views: {
						'' : {
							templateUrl: 'client/trailsEditor/views/listTrail.ng.html',
							controller: 'listTrailCtrl',
						}
					},
					resolve: {
						'subscribe': [ "$meteor", "$stateParams", function($meteor, $stateParams) {
							return $meteor.subscribe('getTrailsByPresId', $stateParams.idpres);
						}]
					}
				})
				.state('premi.editor.trails.new', {
					url: '/editor/:idpres/trails/new',
					views: {
						'': {
							templateUrl: 'client/trailsEditor/views/newTrail.ng.html',
							controller: 'newTrailCtrl',
						},
						'basicToolbar@premi.editor.trails.new': {
							templateUrl: 'client/trailsEditor/views/basicToolbar.ng.html',
							controller: 'basicToolbarCtrl'
						}
					}
				})
				.state('premi.editor.trails.remove', {
					url: '/editor/:idpres/trails/remove/:idtrail',
					views: {
						'': {
							templateUrl: 'client/trailsEditor/views/removeTrail.ng.html',
							controller: 'removeTrailCtrl',
						},
						'basicToolbar@premi.editor.trails.remove': {
							templateUrl: 'client/trailsEditor/views/basicToolbar.ng.html',
							controller: 'basicToolbarCtrl'
						}
					},
					resolve: {
						'subscribe': [ "$meteor", "$stateParams", function($meteor, $stateParams) {
							return $meteor.subscribe('getTrailById', $stateParams.idtrail);
						}]
					}
				})
				.state('premi.editor.trails.edit', {
					url: '/editor/:idpres/trails/edit/:idtrail',
					views: {
						'': {
							templateUrl: 'client/trailsEditor/views/editTrail.ng.html',
							controller: 'editTrailCtrl',
						},
						'basicToolbar@premi.editor.trails.edit': {
							templateUrl: 'client/trailsEditor/views/basicToolbar.ng.html',
							controller: 'basicToolbarCtrl'
						}
					},
					resolve: {
						'subscribe': [ "$meteor", "$stateParams", function($meteor, $stateParams) {
							return $meteor.subscribe('getTrailById', $stateParams.idtrail);
						}]
					}
				})
				.state('premi.editor.trails.modTrail', {
					url: '/editor/:idpres/trails/:idtrail',
					views: {
						'': {
							templateUrl: 'client/trailsEditor/views/modTrail.ng.html',
							controller: 'modTrailCtrl',
						}
					},
					resolve: {
						'subscribe1': [ "$meteor", "$stateParams", function($meteor, $stateParams) {
							console.log($stateParams.idtrail)
							$meteor.subscribe('getTrailById', $stateParams.idtrail).then(function(sub){});
						}],
						'subscribe2': [ "$meteor","$stateParams", function($meteor,$stateParams) {
							return $meteor.subscribe('getInfographicFrames',$stateParams.idpres);
						}],
						'subscribe3': [ "$meteor","$stateParams", function($meteor,$stateParams) {
							return $meteor.subscribe('getInfographicByPresId',$stateParams.idpres);
						}],
					},

				});

			/*$urlRouterProvider
			//	.when('/', '/home')
				.when('/editor', '/editor/frame');
			//	.otherwise('home');*/
		}
	]);