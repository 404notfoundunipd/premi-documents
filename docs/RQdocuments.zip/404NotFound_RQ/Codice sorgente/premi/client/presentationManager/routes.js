angular.module("premi.presentationManager")
	.config(['$urlRouterProvider', '$stateProvider', '$locationProvider',
		function($urlRouterProvider, $stateProvider, $locationProvider){

			$locationProvider.html5Mode(true);

			$stateProvider
				.state('premi.presentationManager', {
					abstract: true,
					views: {
						'': {
							templateUrl: 'client/presentationManager/views/presentationManager.ng.html',
							controller: 'presentationManagerCtrl',
						},
					},
					resolve: {
						currentUser : ["$meteor", function($meteor){
					    	return $meteor.requireUser();
					    }]
					}
				})
				.state('premi.presentationManager.presentations', {
					url: '/presentations',
					views: {
						'': {
							templateUrl: 'client/presentationManager/views/presentations.ng.html',
							controller: 'presentationsCtrl',
						},
					},
					resolve: {
						'subscribe': [ "$meteor", function($meteor) {
							return $meteor.subscribe('getPresentations');
						}]
					}
				})
				.state('premi.presentationManager.newPresentation', {
					url: '/presentations/new',
					views: {
						'': {
							templateUrl: 'client/presentationManager/views/newPresentation.ng.html',
							controller: 'newPresentationCtrl',
						}
					}
				})
				.state('premi.presentationManager.editPresentation', {
					url: '/presentations/edit/:idpres',
					views: {
						'': {
							templateUrl: 'client/presentationManager/views/editPresentation.ng.html',
							controller: 'editPresentationCtrl',
						}
					},
					resolve: {
						'subscribe': [ "$meteor", "$stateParams", function($meteor, $stateParams) {
							return $meteor.subscribe('getPresentationById', $stateParams.idpres);
						}]
					}
				})
				.state('premi.presentationManager.removePresentation', {
					url: '/presentations/remove/:idpres',
					views: {
						'': {
							templateUrl: 'client/presentationManager/views/removePresentation.ng.html',
							controller: 'removePresentationCtrl',
						}
					},
					resolve: {
						'subscribe': [ "$meteor", "$stateParams", function($meteor, $stateParams) {
							return $meteor.subscribe('getPresentationById', $stateParams.idpres);
						}]
					}
				});

			/*$urlRouterProvider
				.when('/presentations', '/presentation');*/
		}
	]);