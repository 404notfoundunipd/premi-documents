angular.module("premi")
	.run(["$rootScope", "$state", function($rootScope, $state) {
		$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
		
			if (error === "AUTH_REQUIRED") {
				$state.go('premi.userManager.signin');
			}
			if (error === 'PARAMS_REQUIRED'){
				$state.go('premi.presentationManager.presentations')
			}
		});
	}])
	.config(['$urlRouterProvider', '$stateProvider', '$locationProvider',
		function($urlRouterProvider, $stateProvider, $locationProvider){

			$locationProvider.html5Mode(true);

			$stateProvider
				.state('premi', {
					abstract: true,
					views: {
						'' : {
							template: '<div ui-view></div>',
							controller: 'premi',
						},
					},
				});

			$urlRouterProvider
				.when('/', '/presentations')
			//	.when('/presentation', '/presentation/list')
				.otherwise('/presentations');
		}]);