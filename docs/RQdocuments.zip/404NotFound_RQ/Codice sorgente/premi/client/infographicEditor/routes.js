angular.module("premi.editor.infographicEditor")
	.config(['$urlRouterProvider', '$stateProvider', '$locationProvider',
		function($urlRouterProvider, $stateProvider, $locationProvider){

			$locationProvider.html5Mode(true);

			$stateProvider
				.state('premi.editor.infographic', {
					url: '/editor/:idpres/infographic',
					views: {
						'' : {
							templateUrl: 'client/infographicEditor/views/infographic.ng.html',
							controller: 'infographicEditorCtrl',
						},
						'frameList@premi.editor.infographic': {
							templateUrl: 'client/infographicEditor/views/frameList.ng.html',
						}
					},
					resolve: {
						'subscribe1' : [ "$meteor","$stateParams", function($meteor,$stateParams) {
							return $meteor.subscribe('getFramesByPresId',$stateParams.idpres);
						}],
						'subscribe2' : ["$meteor","$stateParams", function($meteor,$stateParams){
							return $meteor.subscribe('getInfographicByPresId',$stateParams.idpres);
						}]
					},
				});

			/*$urlRouterProvider
			//	.when('/', '/home')
				.when('/editor', '/editor/frame');
			//	.otherwise('home');*/
		}
	]);