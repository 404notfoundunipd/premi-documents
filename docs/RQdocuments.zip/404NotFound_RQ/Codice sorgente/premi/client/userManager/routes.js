angular.module("premi.userManager")
	.config(['$urlRouterProvider', '$stateProvider', '$locationProvider',
		function($urlRouterProvider, $stateProvider, $locationProvider){

			$locationProvider.html5Mode(true);

			$stateProvider
				.state('premi.userManager', { 
					abstract: true,
					templateUrl: 'client/userManager/views/userManager.ng.html',
					onEnter: function() {
						$('html').addClass('grey darken-4');
					},
					onExit: function () {
						$('html').removeClass('grey darken-4');
					}
				})
				.state('premi.userManager.signin', { 
					url: '/signin',
					views: {
						'' : {
							templateUrl: 'client/userManager/views/signin.ng.html',
							controller: 'signinCtrl'
						}
					},
					resolve: {
						currentUser : ["$meteor", function($meteor){
					    	return $meteor.waitForUser();
					    }]
					}
				})
				.state('premi.userManager.signup', { 
					url: '/signup',
					views: {
						'' : {
							templateUrl: 'client/userManager/views/signup.ng.html',
							controller: 'signupCtrl'
						}
					},
					resolve: {
						currentUser : ["$meteor", function($meteor){
					    	return $meteor.waitForUser();
					    }]
					}
				})
				.state('premi.userManager.changePassword', { 
					url: '/changepassword',
					views: {
						'' : {
							templateUrl: 'client/userManager/views/changePassword.ng.html',
							controller: 'changePasswordCtrl'
						}
					},
					resolve: {
						currentUser : ["$meteor", function($meteor){
					    	return $meteor.requireUser();
					    }]
					}
				})
                .state('premi.userManager.signout', {
					url: '/signout',
					views: {
						'' : {
							controller: 'signoutCtrl'
						},
					},
					resolve: {
						currentUser : ["$meteor", function($meteor){
					    	return $meteor.requireUser();
					    }]
					}
				});

			//$urlRouterProvider
			//	.when('/', '/home')
			//	.when('/presentation', '/presentation/list')
			//	.otherwise('home');
		}
	]);