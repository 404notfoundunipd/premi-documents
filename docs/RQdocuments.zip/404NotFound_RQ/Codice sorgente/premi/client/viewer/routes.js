angular.module("premi.viewer")
	.config(['$urlRouterProvider', '$stateProvider', '$locationProvider',
		function($urlRouterProvider, $stateProvider, $locationProvider){

			$locationProvider.html5Mode(true);

			$stateProvider
				.state('premi.viewer',{
					abstract: true,
					template: '<div ui-view></div>'
				})
				.state('premi.viewer.trails', {
					url: '/present/:idpres',
					views: {
						'' : {
							templateUrl: 'client/viewer/views/trails.ng.html',
							controller: 'trailsCtrl',
						}
					},
					resolve : {
						currentUser : ["$meteor", function($meteor){
					    	return $meteor.requireUser();
					    }],
					    'subscribe1': [ "$meteor", "$stateParams", function($meteor, $stateParams) {
							return $meteor.subscribe('getTrailsByPresId', $stateParams.idpres);
						}],
					}
				})
				.state('premi.viewer.show', {
					url: '/present/:idpres/trail/:idtrail',
					views: {
						'' : {
							templateUrl: 'client/viewer/views/viewer.ng.html',
							controller: 'viewerCtrl',
						},
						'header@premi.viewer.show': {
							templateUrl: 'client/views/header.ng.html'
						}
					},
					resolve: {
						currentUser : ["$meteor", function($meteor){
					    	return $meteor.requireUser();
					    }],
					    'params' : ['$q', '$stateParams', function($q, $stateParams) {
					    	if ($stateParams.idpres == "" || $stateParams.idtrail == "") {
					    		return $q.reject("PARAMS_REQUIRED");
					    	}
					    	return true;
					    }],
					    'subscribe0': [ "$meteor", "$stateParams", function($meteor, $stateParams) {
							return $meteor.subscribe('getPresentationById', $stateParams.idpres);
						}],
					    'subscribe1': [ "$meteor", "$stateParams", function($meteor, $stateParams) {
							return $meteor.subscribe('getTrailById', $stateParams.idtrail);
						}],
						'subscribe2': [ "$meteor","$stateParams", function($meteor,$stateParams) {
							return $meteor.subscribe('getInfographicFrames',$stateParams.idpres);
						}],
						'subscribe3' : ["$meteor","$stateParams", function($meteor,$stateParams) {
							return $meteor.subscribe('getInfographicByPresId',$stateParams.idpres);
						}],
					}
				});

			//$urlRouterProvider
			//	.when('/', '/home')
			//	.when('/presentation', '/presentation/list')
			//	.otherwise('home');
		}
	]);