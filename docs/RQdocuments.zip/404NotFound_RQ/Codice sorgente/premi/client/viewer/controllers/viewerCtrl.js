/**
    * Name:         viewerCtrl.js
    * Package:      premi/client/viewer/controllers
    * Author:       De Lazzari Enrico
    * Date:         2015-08-03

    * Use:
    Controller della vista generata dal template viewer.ng. Fornisce, tramite lo $sco-
    pe, gli attributi ed i metodi necessari alla visualizzazione a allo scorrimento della
    presentazione tramite la libreria impress.js
    
    * Changes:
    Version     Date        Who                 Changes                 Reason
    ----------------------------------------------------------------------------
    0.6         2015-08-13  Cossu Mattia        correzione errore uscita da 
                                                checkpoint
    ----------------------------------------------------------------------------
    0.5         2015-08-12  De Lazzari Enrico   Correzione interazione con impress
    ----------------------------------------------------------------------------
    0.4         2015-08-10  De Lazzari Enrico   pre_init                Correzione errori,
                                                                            miglioramento algoritmo
    ----------------------------------------------------------------------------
    0.3         2015-08-05  De Lazzari Enrico   Incremento Controller, codifica 
                                                    della gestione degli eventi
    ----------------------------------------------------------------------------
    0.2         2015-08-04  Cossu Mattia        Incremento Controller
    ----------------------------------------------------------------------------
    0.1         2015-08-02  De Lazzari Enrico   inizio codifica controller
    ----------------------------------------------------------------------------

    * Created by 404Notfound for Premi - Better than Prezi!

    * Premi is a free software: you can redistribute it and/or modify
    * it under the terms of the GNU General Public License as published by
    * the Free Software Foundation, either version 3 of the License, or
    * (at your option) any later version.

    * This program is distributed in the hope that it will be useful,
    * but WITHOUT ANY WARRANTY; without even the implied warranty of
    * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    * GNU General Public License for more details.

    * You should have received a copy of the GNU General Public License
    * along with this program. If not, see <http://www.gnu.org/licenses/>
*/

angular.module("premi.viewer")
    .controller("viewerCtrl", [ '$scope', '$meteor', '$state', '$stateParams', 'TrailFactory','InfographicFactory','OrderedGOListFactory',
        function($scope, $meteor, $state, $stateParams, TrailFactory, InfographicFactory,OrderedGOListFactory){

            $scope.idtrail = $stateParams.idtrail;

            $scope.play_active = false;     

            var infographicCollection = [];
            var frameCollection = [];
            var trailCollection = [];
            var MTrail = TrailFactory;
            var list = OrderedGOListFactory.initializeList().setOrderBy('lvl');;
            
            $scope.pre_init = function(){

                var pres = Presentations.findOne({'_id' : $stateParams.idpres});
                if (!pres) {
                    alert('testing');
                    $state.go('premi.presentationManager.presentations');
                }

                infographicCollection = Infographics.findOne({"presid" : $stateParams.idpres});

                frameCollection = Frames.find({"_id" : {$in : infographicCollection.framesId}}).fetch();

                console.log(frameCollection);

                trailCollection = Trails.findOne({"_id" : $stateParams.idtrail});
                simpleContentCollection = infographicCollection.content;
                console.log("simplecontent",simpleContentCollection);
                for(var i = 0; i < frameCollection.length; i++){
                    list.insertGO(frameCollection[i]);
                }
                var tempFrameList = [];
                for(var i = 0, li = list.getList(); i < li.length; i++){
                    tempFrameList[i] = li[i]._id;
                }
                for(var key in simpleContentCollection){
                    if(simpleContentCollection.hasOwnProperty(key)){
                        list.insertGO(simpleContentCollection[key]);
                    }
                }
                for(var i=0, li=list.getList(); i<li.length; i++){
                    tempFrameList[i] = li[i]._id;
                }
                MTrail.initPath(tempFrameList,trailCollection.trail);
            };

            $scope.$on('nextSlide', function () {
                console.log("slides",$scope.slides)
                console.log("index",MTrail.getCurrentIndex())
                MTrail.nextSlide();
                $scope.currentSlide = MTrail.getCurrentIndex();
                $scope.goToSlide();
            });

            $scope.$on('previousSlide', function () {
                MTrail.prevSlide();
                $scope.currentSlide = MTrail.getCurrentIndex();
                $scope.goToSlide();
            });

            $scope.$on('enterInCheckPoint', function(){
                if(MTrail.isCurrentSlideChkPnt()){
                    MTrail.enterInCheckPoint();
                    $scope.currentSlide = MTrail.getCurrentIndex();
                    $scope.goToSlide();
                }
            });

            $scope.$on('returnToCheckPoint', function(){
                MTrail.returnToCheckPoint();
                $scope.currentSlide = MTrail.getCurrentIndex();
                $scope.goToSlide();
            });
            $scope.init = function(){
                $scope.play_active = true;
                $('body').removeClass('grey darken-4');
                $('#impresshook').removeClass('hide');
                console.log("init impress")
                console.log($scope.$emit('initImpress'));
            };
            $scope.getContent = function(){
                return list.getList();
            };
            $scope.$on('impressInited',function(){
                $scope.currentSlide = MTrail.getCurrentIndex();
                $scope.goToSlide();
            });
            $scope.pre_init();
  }]);

  