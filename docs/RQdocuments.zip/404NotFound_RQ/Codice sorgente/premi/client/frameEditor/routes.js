angular.module("premi.editor.frameEditor")
	.config(['$urlRouterProvider', '$stateProvider', '$locationProvider',
		function($urlRouterProvider, $stateProvider, $locationProvider){

			$locationProvider.html5Mode(true);

			$stateProvider
				.state('premi.editor.frame', {
					url: '/editor/:idpres/frame',
					views: {
						'' : {
							templateUrl: 'client/frameEditor/views/frame.ng.html',
							controller: 'frameEditorCtrl',
						}/*,
						'frameList@premi.editor.frame': {
							//templateUrl: 'client/frameEditor/views/frameList.ng.html',
							templateUrl: 'client/frameEditor/views/toolbar.ng.html',
						}*/
					},
					resolve: {
						'subscribe': [ "$meteor","$stateParams", function($meteor,$stateParams) {
							return $meteor.subscribe('getFramesByPresId',$stateParams.idpres);
						}]
					},
				});
/*
			$urlRouterProvider
			//	.when('/', '/home')
				.when('/editor', '/editor/frame');
			//	.otherwise('home');*/
		}
	]);