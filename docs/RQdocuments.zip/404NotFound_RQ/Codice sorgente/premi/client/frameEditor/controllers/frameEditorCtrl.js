/** 
    * Name:         frameEditorCtrl.js
    * Package:      premi/client/frameEditor/controllers/
    * Author:       Manuto Monica
    * Date:         2015-07-02

    * Use:
    Questo controller crea lo $scope associato alla vista generata da frame.ng, for-
    nendo i dati e i metodi necessari per consentire all’utente di creare e modellare
    un frame, inserendo o rimuovendo oggetti grafici al suo interno.
    
    * Changes:
    Version     Date        Who                 Changes             Reason
    ----------------------------------------------------------------------------
    0.9         2015-07-29  De Lazzari Enrico                       correzioni
    ----------------------------------------------------------------------------
    0.8         2015-07-18  De Lazzari Enrico   aggiunta stati
    ----------------------------------------------------------------------------
    0.7         2015-07-16  De Lazzari Enrico   setObserver,        correzioni metodo
                                                addGObject
    ----------------------------------------------------------------------------
    0.6         2015-07-15  De Lazzari Enrico   incremento classe
    ----------------------------------------------------------------------------
    0.5         2015-07-12  De Lazzari Enrico   incremento classe
    ----------------------------------------------------------------------------
    0.4         2015-07-08  De Lazzari Enrico   incremento classe
    ----------------------------------------------------------------------------
    0.3         2015-07-08  Manuto Monica       interactIniter      modificato attributo e
                                                                    sue associazioni
    ----------------------------------------------------------------------------
    0.2         2015-07-07  Manuto Monica       incremento metodi 
    ----------------------------------------------------------------------------
    0.1         2015-07-02  Manuto Monica       inizio classe
    ----------------------------------------------------------------------------

    * Created by 404Notfound for Premi - Better than Prezi!

    * Premi is a free software: you can redistribute it and/or modify
    * it under the terms of the GNU General Public License as published by
    * the Free Software Foundation, either version 3 of the License, or
    * (at your option) any later version.

    * This program is distributed in the hope that it will be useful,
    * but WITHOUT ANY WARRANTY; without even the implied warranty of
    * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    * GNU General Public License for more details.

    * You should have received a copy of the GNU General Public License
    * along with this program. If not, see <http://www.gnu.org/licenses/>
*/

angular.module("premi.editor.frameEditor")
    .controller("frameEditorCtrl", ['OrderedGOListFactory','$scope','$stateParams','databaseAPI','InteractInit' ,'FrameFactory','Observer','$state',
        function(OrderedGOListFactory,$scope,$stateParams, databaseAPI, InteractInit, FrameFactory,Observer,$state){

            $(document).ready(function(){
                $('.tooltipped').tooltip({delay: 50});
                $('.modal-trigger').leanModal();

                // XGA resolution
                $scope.standard_height = 768;
                $scope.standard_width = 1024;
            });

            $('body').click(function () {
                $('#choiceShape').closeModal();
            });



            var framesId = [];
            var frames = {};
            
            /*modifica 2015-07-27*/
            var frameCollection = Frames.find({presid : $stateParams.idpres}).fetch();
            var observer = Observer;
            var interactIniter = InteractInit.setObserver(observer).setRestrictArea("dropzone");
            var db = databaseAPI;
            var imageSet = false;
            var list = OrderedGOListFactory.initializeList().setOrderBy('lvl');
            var currentFrame = FrameFactory;
            /*list.setOrderBy("p").insertGO({_id:"1",p:1}).insertGO({_id:"2",p:2}).insertGO({_id:"3",p:3}).insertGO({_id:"5",p:5}).insertGO({_id:"4",p:4});
            console.log("test List")
            console.log(list.getList());
            list.selectGO("4");
            list.getList()[3].p = 10;
            list.updateCatch().insertGO({_id:"6",p:9});
            list.selectGO("5");
            list.getList()[3].p = 2;
            list.updateCatch().removeGO("5");
            console.log(list.getList());*/
            $scope.wraPrefix = "wrapper-";
            $scope.states = Object.freeze({
                noSelection  : 1,
                imageEditing : 2,
                shapeEditing : 3,
                textEditing  : 4,
                addingGO     : 5,
                framesList   : 6,
            });
            $scope.currentState = $scope.states.noSelection;
            $scope.currentImage = "";
            $scope.colorTextSelected = '#000000';
            $scope.sizeFontText = 20;

            var initInteract = function(GO){
                switch(GO.type){
                    case "image" : 
                        interactIniter.initializeImage($scope.wraPrefix + GO._id);
                        break;
                    case "shape" :
                        interactIniter.initializeShape($scope.wraPrefix + GO._id);
                        break;
                    case "text"  :
                        interactIniter.initializeText($scope.wraPrefix + GO._id);
                        break;
                }
            };
            var removeFrameFromIdArray = function(idFrame){
                for(var i = 0, found = false; i < framesId.length && !found; i++){
                    if(framesId[i] == idFrame){
                        framesId.splice(i,1);
                        if(framesId.length == 0){
                            return -1;
                        }
                        if(i == framesId.length)
                            return framesId.length -1;
                        return i;
                    }
                }
                return 0;
            };

            var getIdGOByWrapper = function(idWrapperGO){
                return idWrapperGO.substring($scope.wraPrefix.length);
            };

            var setObserver = function(){
                observer
                    .on('select',function (idWrapperGO){
                        var idGO = getIdGOByWrapper(idWrapperGO);
                        if(currentFrame.getSelectedGOId() != idGO){
                            currentFrame.selectGO(idGO);
                            $scope.currentState = $scope.states[currentFrame.getSelectedGOType() + 'Editing'];
                            if(!$scope.$$phase){
                                $scope.$apply();
                            }                            
                        }
                    })
                    .on('resize',function (resize){
                        currentFrame.resizeGO(resize);
                        if(!$scope.$$phase){
                            $scope.$apply();
                        }
                    })
                    .on('drag',function (drag){
                        currentFrame.dragGO(drag);
                        if(!$scope.$$phase){
                            $scope.$apply();
                        }
                    })
                    .on('update',function (update){
                        currentFrame.updateGO(update);
                        if(!$scope.$$phase){
                            $scope.$apply();
                        }
                    })
                    .on('changeLvl',function (idGO,lvl){
                        currentFrame.updateGO({lvl:lvl},idGO);
                        if(!$scope.$$phase){
                            $scope.$apply();
                        }

                    });


            };

            var imageIsLoaded = function(e) {
                currentFrame.updateSelectedGO({src:e.target.result});
                if(!$scope.$$phase){
                    $scope.$apply();
                }
            }; 

            $scope.disableAllStateMenu = function () {
                $scope.currentState = $scope.states.noSelection;
            };

            $scope.enableStateMenu = function (stateMenu) {
                switch(stateMenu) {
                    case 'framesListMenu':
                        $scope.currentState = $scope.states.framesList;
                        break;
                    case 'addGraphicObjectMenu':
                        $scope.currentState = $scope.states.addingGO;
                        break;
                    case 'editTextMenu':
                        $scope.currentState = $scope.states.textEditing;
                        break;              
                    case 'editShapeMenu':
                        $scope.currentState = $scope.states.shapeEditing;
                        break;
                    default:
                        $scope.disableAllStateMenu();
                }
            };

            $scope.goToState = function (state) {
                $state.go(state, $stateParams);
            };

            $scope.getCurrentId = function(){
                if(currentFrame)
                    return currentFrame.getId();
                else 
                    return null;
            }
            $scope.getFramesId = function(){
                return frames;
            };
            /*modifica 2015-07-27*/
            $scope.getGOContent = function(){
                return list.getList();
            };

            $scope.getSelectedGOId = function(){
                if(currentFrame){
                    return currentFrame.getSelectedGOId();
                }
                else{
                    return undefined;
                }
            };

            $scope.changeImage = function(file){
                file = file.files[0];
                var reader = new FileReader();
                reader.onload = imageIsLoaded; 
                reader.readAsDataURL(file);
            };

            $scope.selectFrame = function(idFrame){
                if(currentFrame.getId() != idFrame){
                    currentFrame.save();
                    currentFrame.initByJSON(frames[idFrame]);
                    list.initializeList();
                    for(var key in currentFrame.getGOContent()){
                        /*modifica 2015-07-27*/   
                        list.insertGO(currentFrame.getGOContent()[key]);
                        initInteract(currentFrame.getGOContent()[key]);
                    }
                }
            };
            $scope.saveFrame = function(){
                currentFrame.save();
            };

            $scope.removeGO = function(){
                var idGO = currentFrame.getSelectedGOId();
                currentFrame.removeSelectedGO();
                list.removeGO(idGO);
                currentFrame.deselectGO();
                $scope.currentState = $scope.states.noSelection;
            }; 

            $scope.removeFrame = function(idFrame){
                if(!idFrame){
                    if(currentFrame)
                        idFrame = currentFrame.getId();
                    else 
                        return;
                }
                $scope.currentState = $scope.states.noSelection;
                db.removeFrame(idFrame, function(idFrame){
                    var pos = removeFrameFromIdArray(idFrame);
                    if(pos == -1){
                        currentFrame = null;
                        return;
                    }
                    if(currentFrame.getId() == idFrame){
                        currentFrame.initByJSON(frames[framesId[pos]]);
                    }
                })
            };

            $scope.addGO = function(){
                $scope.currentState = $scope.states.addingGO;
            };

            $scope.selectGO = function($event,idGO,type){
                $event.stopPropagation();
                currentFrame.selectGO(idGO);
                $scope.disableAllStateMenu();
                $scope.currentState = $scope.states[type+'Editing'];
                if(type == "shape"){
                }
                //console.log($scope.currentState+"="+$scope.states.textEditing);
                if (type == 'text') {
                    $scope.textareaInput = currentFrame.getGOJSON(currentFrame.getSelectedGOId()).text;
                    setTextDimensionByText($scope.textareaInput);
                    $scope.colorTextSelected = currentFrame.getGOJSON(currentFrame.getSelectedGOId()).colorText;
                    var fontpx = currentFrame.getGOJSON(currentFrame.getSelectedGOId()).sizeFontText;
                    fontpx = parseInt(fontpx);
                    $scope.sizeFontText = fontpx;
                }
                if(type == 'image'){
    
                }
                

                //alert($scope.sizeFontText);
                //alert($scope.colorTextSelected);
            };

            $scope.removeSelection = function(){
                if(currentFrame)
                    currentFrame.deselectGO();
                $scope.currentState = $scope.states.noSelection;
                $scope.colorTextSelected = "#000000";
                $scope.sizeFontText = 20;
                $scope.disableAllStateMenu();
            };

            $scope.addGObject = function (type,params) {
                $scope.disableAllStateMenu();
                switch(type){
                    case "frame" : 
                        if(!currentFrame){
                            currentFrame = FrameFactory;
                        }
                        currentFrame.initByDefault();
                        db.insertFrame($stateParams.idpres,function (newId){
                            frames[newId] = currentFrame.getJSON();
                            framesId.push(newId);
                            currentFrame.setId(newId);
                            currentFrame.initByJSON(currentFrame.getJSON());
                        });
                        list.initializeList();
                        break;
                    case "image" :
                        currentFrame.addGO({type:'image'});
                        list.insertGO(currentFrame.getGOJSON(currentFrame.getSelectedGOId()));
                        interactIniter.initializeImage($scope.wraPrefix+currentFrame.getSelectedGOId());
                        $scope.currentState = $scope.states.imageEditing;
                        $("#uploadImageBtnn").click();
                        break;
                    case "shape" :
                        currentFrame.addGO({type:'shape',src:params});
                        list.insertGO(currentFrame.getGOJSON(currentFrame.getSelectedGOId()));
                        interactIniter.initializeShape($scope.wraPrefix+currentFrame.getSelectedGOId());
                        $scope.currentState = $scope.states.shapeEditing;
                        break;
                    case "text" : 
                        currentFrame.addGO({type:'text',text:'text',colorText:'#000000',weight:'',fontStyle:'',textDecoration:'',sizeFontText:'20',fontFamily:'Arial'});
                        list.insertGO(currentFrame.getGOJSON(currentFrame.getSelectedGOId()));
                        interactIniter.initializeText($scope.wraPrefix+currentFrame.getSelectedGOId());                    
                        currentFrame.updateSelectedGO({width: '2', height: 'auto'});
                        $scope.colorTextSelected = currentFrame.getGOJSON(currentFrame.getSelectedGOId()).colorText;
                        var fontpx = currentFrame.getGOJSON(currentFrame.getSelectedGOId()).sizeFontText;
                        fontpx = parseInt(fontpx);
                        $scope.sizeFontText = fontpx; 
                        $scope.currentState = $scope.states.textEditing;
                        break;
                }
            };
            var setTextDimensionByText = function(textareaInput){
                var row = textareaInput;
                row = row.split('\n');
                var maxwidth = 0;
                for (var i=0;i<row.length;i++) {
                    if (row[i].length > maxwidth) {
                        maxwidth = row[i].length;
                    }
                }
                var heightText = row.length;
                
                $scope.textareaWidth = maxwidth/2 +0.5;
                $scope.textareaHeight = heightText*2+0.5;
            }
            $scope.changeInputTextarea = function(textareaInput) {
                setTextDimensionByText(textareaInput);
                currentFrame.updateSelectedGO({text: textareaInput, width: $scope.textareaWidth-(10*$scope.textareaWidth/100), height: $scope.textareaHeight});
            }

            $scope.clickDropzone = function() {
                $scope.disableAllStateMenu();
                if (currentFrame) {
                    currentFrame.deselectGO();
                }            
            };

           $scope.getColorText = function() {
           // return currentFrame.getGOJSON(currentFrame.getSelectedGOId()).colorText;
              return $scope.colorTextSelected;

           };

            $scope.changeImageShape = function(srcShape) {
                //var idShape = $scope.currentFrame.selectedGo.getId();          
                //$scope.currentFrame.updateGO([src,srcShape],idShape);
                currentFrame.updateSelectedGO({src: '/svg/'+srcShape});
            };

            $scope.changeWeight = function(valueWeight) {
                currentFrame.updateSelectedGO({weight: valueWeight});
            };

            $scope.changeFontStyle = function(valueFontStyle) {
                currentFrame.updateSelectedGO({fontStyle: valueFontStyle});
            };

            $scope.changeTextDecoration = function(valueTextDecoration) {
                currentFrame.updateSelectedGO({textDecoration: valueTextDecoration});
            };

            $scope.changeColorText = function(colorText) {
                $scope.colorTextSelected = colorText;
                currentFrame.updateSelectedGO({colorText: $scope.colorTextSelected});
                
            };

            $scope.changeFontSizeText = function(sizeFontText) {
                $scope.sizeFontText = sizeFontText;
                currentFrame.updateSelectedGO({sizeFontText: $scope.sizeFontText});
                  
            };

            $scope.resetChange = function() {
                currentFrame.updateSelectedGO({textDecoration: '',fontStyle: '',weight: ''});
            };

            $scope.getBackgroundColorDropzone = function() {
                return currentFrame.getBackgroundColor();
            };

            $scope.changeBackgroundColorDropzone = function(colorText) {
                currentFrame.set('backgroundColor',colorText);
            };

            $scope.changeFontFamilyText = function(fontFamily) {
                currentFrame.updateSelectedGO({fontFamily: fontFamily});
            }

            $scope.dragTextEnable = function(){
                interactIniter.initializeText($scope.wraPrefix + currentFrame.getSelectedGOId());
            };

            $scope.dragTextDisable = function(){
                interactIniter.unSet($scope.wraPrefix + currentFrame.getSelectedGOId());
            };

            var init = function(){
                setObserver();
                interactIniter.setObserver(observer);
                for(var i=0;i<frameCollection.length;i++){
                    framesId[i] = frameCollection[i]._id;
                    frames[framesId[i]] = frameCollection[i];
                }
                if(framesId.length == 0){
                    currentFrame = null;
                }
                else{
                    for(var key in frames[framesId[0]].content){
                        list.insertGO(frames[framesId[0]].content[key]);
                        if(frames[framesId[0]].content[key].type!="text")
                        initInteract(frames[framesId[0]].content[key]);   
                    }
                    currentFrame.initByJSON(frames[framesId[0]]);
                }
                $scope.disableAllStateMenu();

                
            };
            
            init();
        
        }
    ]);