Presentations = new Mongo.Collection("Presentations");

Trails = new Mongo.Collection("Trails");

Frames = new Mongo.Collection("Frames");

Infographics = new Mongo.Collection("Infographics");